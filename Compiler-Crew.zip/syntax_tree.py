import itertools


# Abstract Syntax tree
class ASTNode:
    _id_counter = itertools.count()

    def __init__(self, nodetype, value=None, children=None):
        self.id = next(ASTNode._id_counter)
        self.type = nodetype  # e.g., "VAR", "FUNC", "PROC", "ASSIGN"
        self.value = value  # e.g., variable name, function name, number
        self.children = children or []

    def __repr__(self):
        child_str = ", ".join([str(c) for c in self.children])
        return f"{self.type}(id={self.id}, value={self.value}, children={child_str})"


# Node types
class ProgramNode(ASTNode):
    def __init__(self, globals_node, procs_node, funcs_node, main_node):
        super().__init__(
            "PROGRAM", children=[globals_node, procs_node, funcs_node, main_node]
        )


class VarDeclNode(ASTNode):
    def __init__(self, name):
        super().__init__("VAR", value=name)


class FuncNode(ASTNode):
    def __init__(self, name, params, body, ret):
        super().__init__("FUNC", value=name, children=params + [body])
        self.return_type = ret

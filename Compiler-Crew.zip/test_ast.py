# test_ast.py
from symbol_table import SymbolTable
from syntax_tree import VarDeclNode, ProgramNode
from parser import build_spl_grammar, SLRParser, Token, TokenType

# Build symbol table root
root = SymbolTable("everywhere")

# Fake AST: glob { x y }
globals_scope = root.create_child_scope("global")
var_x = VarDeclNode("x")
globals_scope.add("x", "var", node_id=var_x.id)

var_y = VarDeclNode("y")
globals_scope.add("y", "var", node_id=var_y.id)

# Build AST program
program = ProgramNode(
    globals_node=[var_x, var_y], procs_node=None, funcs_node=None, main_node=None
)

print("AST:", program)
print("Symbol Table:", root)
